
def test_given_a_phonebook_has_multiple_contacts_with_same_name_when_looking_up_name_then_return_phone_all_phone_numbers_for_that_name():
    book = PhoneBook()
    #Given
    book.add_contact("Polisen", "11414")
    book.add_contact("Polisen", "112")
    book.add_contact("Polisen", "666")
    #When
    all_numbers = book.lookup("Polisen")
    #Then
    expected_numbers = ("11414", "112", "666")
    self.assertEqual(all_numbers, expected_numbers)
