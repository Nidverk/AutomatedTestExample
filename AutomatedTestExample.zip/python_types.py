a = 15
print(a+1)
b = "15"
print(b+1)