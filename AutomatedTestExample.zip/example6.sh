#example6.sh

pathCSW=/home/tuc9/Testautomation
pathPython=python3
pathPythonCode=/home/tuc9/Testautomation/Tja.py
pathJava=java
pathJavaCode=/home/tuc9/Testautomation/Hejhej.java

testFail=0
testPass=0
# Anger operativsystemet
os_name=$(uname -s)

timestamp="$(date +"%T")"
starttime=$(date +%s)
logNamed="log$timestamp.txt"
echo $logNamed

# Tidsstämpla loggen
filename='test_260names.txt'
#filename=$1 tar första argumentet i filen.
echo "Startar logg ___________________________________________" >>$logNamed
n=1
starttimep=$(date +%s)
while read line|| [[ -n "$line" ]]; do
# reading each line

CURRENTDATE= date +"%Y-%m-%d %H:%M:%S" >>$logNamed
comp="Testsvar: $line"
echo "Python">>$logNamed
echo "Testsvar: $line" >>$logNamed

testSvarP=$($pathPython $pathPythonCode $line)
echo "Pyto : "$testSvarP
echo "Comp : "$comp

if [ "$testSvarP" = "$comp" ];then
    echo "PASS"
    echo "pass">>$logNamed
    echo "Pyto : "$testSvarP
    echo "Comp : "$comp
    ((testPass=testPass+1))
else
    echo "FAIL">>$logNamed
    echo "FAIL"
    echo "Pyto : "$testSvarP
    echo "Comp : "$comp
    ((testFail=testFail+1))
fi

done < $filename
endtimep=$(date +%s)
elapsedtimep=$((endtimep - starttimep))
echo $elapsedtime

starttimej=$(date +%s)

while read line|| [[ -n "$line" ]]; do
##Exekvera Java
comp="Testsvar: $line"
echo "Java">>$logNamed
testSvarJ=$($pathJava $pathJavaCode $line)
 echo $testSvarJ>>$logNamed

if [ "$testSvarJ" = "$comp" ];then
   echo "pass">>$logNamed
   ((testPass=testPass+1))
else
   echo "FAIL">>$logNamed
   ((testFail=testFail+1))
fi

done < $filename
endtimej=$(date +%s)
elapsedtimej=$((endtimej - starttimej))

starttimec=$(date +%s)
while read line|| [[ -n "$line" ]]; do
comp="Testsvar: $line"
echo "C Code">>$logNamed
testSvarC=$($pathCSW/kalle $line)
echo $testSvarC>>$logNamed

#Compare
if [ "$testSvarC" = "$comp" ];then
   echo "pass">>$logNamed
   ((testPass=testPass+1))
else
   echo "FAIL">>$logNamed
   ((testFail=testFail+1))
fi

echo "****************************************************">>$logNamed
timestamp="$(date +"%T")"
echo $timestamp>>$logNamed

n=$((n+1))
done < $filename
endtimec=$(date +%s)
elapsedtimec=$((endtimec - starttimec))
endtime=$(date +%s)
elapsedtime=$((endtime - starttime))
testRun=$((testPass+testFail))

echo "Test Run : " $testRun
echo "Test  Pass : " $testPass
echo "Test  Fail : " $testFail
echo "Test Run : " $testRun >>$logNamed
echo "Test  Pass : " $testPass>>$logNamed
echo "Test  Fail : " $testFail>>$logNamed

echo "EOF" >>$logNamed

htmlReport="TestRapport$timestamp.html"

echo "<h1>Test Rapport $timestamp </h1>">>$htmlReport
echo "<body>Time to run in Seconds : $elapsedtime  Python: $elapsedtimep  Java: $elapsedtimej  C: $elapsedtimec<br></body>">>$htmlReport
echo "<body>Test Run : $testRun<br></body>">>$htmlReport
echo "<body>Test Pass : $testPass<br></body>">>$htmlReport
echo "<body>Test fail : $testFail<br></body>">>$htmlReport
echo "<body>Operating system: $os_name<br></body>">>$htmlReport
pathLOG=$(pwd)
echo "<a href=$pathLOG/$logNamed> Log file : $logNamed<br><br></a>">>$htmlReport

byWHO=$(whoami)
echo "<body>Run b : $byWHO<br><body>">>$htmlReport