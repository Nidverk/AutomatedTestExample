package Hejhej;

public class Hejhej{
    
    public static void main(String[] args) {
        if ( args.length == 1 )
            System.out.println("Testsvar: "+args[0]);
        else if( args.length > 1 )
            System.out.println("Too many");
        else 
            System.out.println("One expected");
    }
}