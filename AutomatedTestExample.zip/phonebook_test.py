# from phonebook import PhoneBook

# def test_new_phonebook_has_no_contacts():
#     book = PhoneBook()
#     assert book.no_of_contacts() == 0

# def test_given_an_empty_phonebook_when_one_contact_is_added_there_is_one_contact():
#     Given
#     book = PhoneBook()
#     When
#     book.add_contact("Polisen", "11414")
#     Then
#     assert book.no_of_contacts() == 1

# def test_given_a_phonebook_with_a_contact_it_will_be_shown():
#     Given
#     book = PhoneBook()
#     book.add_contact("Polisen", "11414")
#     When/Then
#     assert book.lookup("Polisen") == "11414"

# def test_given_a_phonebook_with_a_contact_when_contact_deleted_should_be_deleted():
#     Given
#     book = PhoneBook()
#     book.add_contact("Polisen", "11414")
#     When
#     book.delete("Polisen")
#     Then
#     assert book.no_of_contacts() == 0

# def test_when_searching_using_name_should_return_name():
#     book = PhoneBook()
#     book.add_contact("Polisen", "11414")
#     assert book.lookupNumber("11414") == "Polisen"

# def test_when_a_phonebook_has_added_two_contacts_it_should_have_two_contacts():
#     book = PhoneBook()
#     book.add_contact("Polisen", "11414")
#     book.add_contact("NYPD", "911")
#     assert book.no_of_contacts() == 2

# def test_given_a_phonebook_with_two_contacts_should_still_find_correct_number():
#     book = PhoneBook()
#     book.add_contact("NYPD", "911")
#     book.add_contact("Polisen", "11414")
#     assert book.lookup("Polisen") == "11414"

# def test_given_a_phonebook_with_multiple_contacts_when_cleared_it_should_have_no_contacts():
#     book = PhoneBook()
#     book.add_contact("NYPD", "911")
#     book.add_contact("Polisen", "11414")
#     book.remove_all_contacts()
#     assert book.no_of_contacts() == 0


# def test_given_a_phonebook_has_a_contact_when_nonexistent_contact_is_deleted_then_phonebook_should_have_a_contact():
#     #Given
#     book = PhoneBook()
#     book.add_contact("Polisen", "11414")
#     #When
#     book.delete("Rickardstelnacke")
#     #Then
#     assert book.no_of_contacts() == 1
#     # assert book.lookup("Rickardstelnacke")

