def calc(a):
    if "+":
        return 2
    elif "*":
        return 6

# def calc(a):
#     if "+":
#         return 2
#     else:
#         return 6


# import sys

# def calc(args):
#     if args[1] == '+':
#         return int(args[0]) + int(args[2])
#     elif args[1] == '*':
#         return int(args[0]) * int(args[2])
    

# if __name__ == "__main__":
#     print(calc(sys.argv[1:]))