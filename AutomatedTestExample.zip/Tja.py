import sys

if len(sys.argv) == 2:
    print("Testsvar: "+str(sys.argv[1]))
elif len(sys.argv) > 1:
    print("För mycket argumentation")
else:
    print("Minst ett argument")