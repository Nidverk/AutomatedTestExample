class PhoneBook():

    def __init__(self, duplicateDetector):
        self.duplicateDetector = duplicateDetector
        self.contacts = []

    def no_of_contacts(self):
        return len(self.contacts)
    
    def add_contact(self, name, number):
        self.contacts.append((name, number))

    def lookup(self, name):
        for contact_name, contact_number in self.contacts:
            if name == contact_name:
                return contact_number