# class PhoneBook():

#     def __init__(self, duplicateDetector):
#         self.duplicateDetector = duplicateDetector
#         self.contacts = []
        

#     def no_of_contacts(self):
#         return len(self.contacts)
    
#     def add_contact(self, name, number):
#         self.contacts.append((name, number))

#     def lookup(self, name):
#         for contact_name, contact_number in self.contacts:
#             if name == contact_name:
#                 return contact_number
    
#     def delete(self, name):
#         self.contacts.pop()

#     def lookupNumber(self, number):
#         return self.contacts[0][0]
    
#     def remove_all_contacts(self):
#         self.contacts.clear()

#     def function_that_needs_duplicator(self):
#         if self.duplicateDetector.hasDuplicates():
#             print("Duplicates!")